
#include <stdio.h>

int main()
{
    double R1, R2;
    double G;
    printf ("Ingrese el valor de R1:");
    scanf("%lf", &R1);
    printf ("Ingrese el valor de R2:");
    scanf("%lf", &R2);
    G=R2/(R1+R2);
    printf ("El valor de la ganancia es: %lf\n", G);
    return 0;
    
}
